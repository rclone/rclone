<?php
namespace Jamm\Memory\Tests;

class MethodsComparisonResults
{
	public $new_methods;
	public $obsolete_methods;
	public $diff_methods;
}