This is a test .zip file
